import React, { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";

// Theme colors
const colors = {
  deepBlue: "#0D1B2A",
  orangeRed: "#FF4500",
  yellowOrange: "#FFA500",
  white: "#ffffff",
};

const containerStyle = {
  minHeight: "100vh",
  backgroundColor: colors.deepBlue,
  padding: "40px",
  fontFamily: "'Segoe UI', sans-serif",
  color: colors.white,
};

const cardGrid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
  gap: "20px",
  marginBottom: "30px",
};

const cardStyle = {
  backgroundColor: colors.white,
  borderRadius: "12px",
  padding: "20px",
  textAlign: "center",
  boxShadow: "0 4px 15px rgba(0,0,0,0.15)",
  color: colors.deepBlue,
};

const chartContainer = {
  backgroundColor: colors.white,
  borderRadius: "12px",
  padding: "20px",
  boxShadow: "0 4px 15px rgba(0,0,0,0.15)",
  marginBottom: "30px",
};

function Reporting() {
  const [summary, setSummary] = useState({});
  const [monthlyData, setMonthlyData] = useState([]);
  const [currencyData, setCurrencyData] = useState([]);

  useEffect(() => {
    // Mock summary data
    setSummary({
      totalPayments: 128,
      totalAmount: "$2,345,000",
      activeCustomers: 56,
      employees: 12,
    });

    // Mock monthly payments chart data
    setMonthlyData([
      { month: "Jan", amount: 200000 },
      { month: "Feb", amount: 180000 },
      { month: "Mar", amount: 220000 },
      { month: "Apr", amount: 260000 },
      { month: "May", amount: 300000 },
      { month: "Jun", amount: 280000 },
    ]);

    // Mock currency distribution data
    setCurrencyData([
      { name: "USD", value: 45 },
      { name: "EUR", value: 30 },
      { name: "GBP", value: 15 },
      { name: "ZAR", value: 10 },
    ]);
  }, []);

  const pieColors = [colors.orangeRed, colors.yellowOrange, "#3b82f6", "#10b981"];

  return (
    <div style={containerStyle}>
      <h2 style={{ marginBottom: "20px" }}> Reporting & Analytics</h2>

      {/* Summary cards */}
      <div style={cardGrid}>
        <div style={cardStyle}>
          <h3>{summary.totalPayments}</h3>
          <p>Total Payments</p>
        </div>
        <div style={cardStyle}>
          <h3>{summary.totalAmount}</h3>
          <p>Total Amount Processed</p>
        </div>
        <div style={cardStyle}>
          <h3>{summary.activeCustomers}</h3>
          <p>Active Customers</p>
        </div>
        <div style={cardStyle}>
          <h3>{summary.employees}</h3>
          <p>Employees</p>
        </div>
      </div>

      {/* Monthly Payments Chart */}
      <div style={chartContainer}>
        <h3 style={{ color: colors.deepBlue, marginBottom: "10px" }}>Monthly Payments Volume</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={monthlyData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="amount" fill={colors.orangeRed} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Currency Distribution Pie */}
      <div style={chartContainer}>
        <h3 style={{ color: colors.deepBlue, marginBottom: "10px" }}>Payments by Currency</h3>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={currencyData}
              dataKey="value"
              nameKey="name"
              outerRadius={100}
              fill={colors.orangeRed}
              label
            >
              {currencyData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={pieColors[index % pieColors.length]} />
              ))}
            </Pie>
            <Legend />
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export default Reporting;
