import React, { useEffect, useState } from "react";
import axios from "axios";

// Theme colors
const colors = {
  deepBlue: "#0D1B2A",
  orangeRed: "#FF4500",
  yellowOrange: "#FFA500",
  lightGray: "#f4f6f9",
  white: "#ffffff"
};

const containerStyle = {
  backgroundColor: colors.deepBlue,
  minHeight: "100vh",
  padding: "40px",
  fontFamily: "'Segoe UI', sans-serif",
  color: colors.white
};

const cardStyle = {
  backgroundColor: colors.white,
  color: colors.deepBlue,
  borderRadius: "12px",
  padding: "24px",
  maxWidth: "900px",
  margin: "0 auto",
  boxShadow: "0 4px 20px rgba(0, 0, 0, 0.1)"
};

const tableStyle = {
  width: "100%",
  borderCollapse: "collapse",
  marginTop: "20px"
};

const thStyle = {
  backgroundColor: colors.orangeRed,
  color: "#fff",
  padding: "12px",
  textAlign: "left",
  fontSize: "16px"
};

const tdStyle = {
  padding: "12px",
  borderBottom: "1px solid #e0e0e0",
  fontSize: "15px"
};

function TransactionHistory() {
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    // Replace this with your actual API
    axios.get("https://your-api/transactions")
      .then(res => setTransactions(res.data))
      .catch(err => {
        console.error(err);
        alert("Failed to fetch transactions");
      });
  }, []);

  return (
    <div style={containerStyle}>
      <div style={cardStyle}>
        <h2 style={{ marginBottom: "16px", fontWeight: "600" }}>
          🧾 Transaction History
        </h2>

        {transactions.length === 0 ? (
          <p>No transactions found.</p>
        ) : (
          <table style={tableStyle}>
            <thead>
              <tr>
                <th style={thStyle}>Date</th>
                <th style={thStyle}>Recipient</th>
                <th style={thStyle}>Amount</th>
                <th style={thStyle}>Currency</th>
                <th style={thStyle}>SWIFT</th>
                <th style={thStyle}>Reference</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((txn, idx) => (
                <tr key={idx}>
                  <td style={tdStyle}>{txn.date}</td>
                  <td style={tdStyle}>{txn.recipient}</td>
                  <td style={tdStyle}>{txn.amount}</td>
                  <td style={tdStyle}>{txn.currency}</td>
                  <td style={tdStyle}>{txn.swift}</td>
                  <td style={tdStyle}>{txn.reference || "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default TransactionHistory;
