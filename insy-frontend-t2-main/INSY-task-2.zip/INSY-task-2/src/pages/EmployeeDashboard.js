import React from "react";
import { Link } from "react-router-dom";


// Theme colors
const colors = {
  deepBlue: "#0D1B2A",
  orangeRed: "#FF4500",
  yellowOrange: "#FFA500",
  white: "#ffffff",
};

const containerStyle = {
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  height: "100vh",
  fontFamily: "'Segoe UI', sans-serif",
  backgroundColor: colors.deepBlue,
};

const cardStyle = {
  backgroundColor: colors.white,
  padding: "40px",
  borderRadius: "12px",
  boxShadow: "0 4px 20px rgba(0, 0, 0, 0.15)",
  width: "450px",
  textAlign: "center",
};

const headingStyle = {
  color: colors.deepBlue,
  marginBottom: "24px",
};

const buttonStyle = {
  backgroundColor: colors.orangeRed,
  color: "#fff",
  border: "none",
  padding: "14px 24px",
  margin: "12px 0",
  borderRadius: "8px",
  cursor: "pointer",
  fontSize: "16px",
  width: "100%",
  transition: "0.3s ease",
};

const hoverStyle = {
  backgroundColor: colors.yellowOrange,
  color: colors.deepBlue,
};

function EmployeeDashboard() {
  return (
    <div style={containerStyle}>
      <div style={cardStyle}>
        <h2 style={headingStyle}> Employee Dashboard</h2>

        <Link to="/employee-payments">
          <button
            style={buttonStyle}
            onMouseOver={(e) => Object.assign(e.target.style, hoverStyle)}
            onMouseOut={(e) => Object.assign(e.target.style, buttonStyle)}
          >
            View All Payments
          </button>
        </Link>

        <Link to="/manage-customers">
          <button
            style={buttonStyle}
            onMouseOver={(e) => Object.assign(e.target.style, hoverStyle)}
            onMouseOut={(e) => Object.assign(e.target.style, buttonStyle)}
          >
            Manage Customers
          </button>
        </Link>

        <Link to="/reporting">
          <button
            style={buttonStyle}
            onMouseOver={(e) => Object.assign(e.target.style, hoverStyle)}
            onMouseOut={(e) => Object.assign(e.target.style, buttonStyle)}
          >
            Reporting & Analytics
          </button>
        </Link>
      </div>
    </div>
  );
}

export default EmployeeDashboard;
