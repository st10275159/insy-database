import React, { useEffect, useState } from "react";
import axios from "axios";

// Theme colors
const colors = {
  deepBlue: "#0D1B2A",
  orangeRed: "#FF4500",
  yellowOrange: "#FFA500",
  white: "#ffffff",
};

const containerStyle = {
  minHeight: "100vh",
  backgroundColor: colors.deepBlue,
  padding: "40px",
  fontFamily: "'Segoe UI', sans-serif",
  color: colors.white,
};

const cardStyle = {
  backgroundColor: colors.white,
  borderRadius: "12px",
  padding: "24px",
  boxShadow: "0 4px 15px rgba(0,0,0,0.15)",
};

const headingStyle = {
  fontSize: "22px",
  fontWeight: "600",
  marginBottom: "20px",
  color: colors.deepBlue,
};

const tableStyle = {
  width: "100%",
  borderCollapse: "collapse",
};

const thStyle = {
  backgroundColor: colors.orangeRed,
  color: colors.white,
  textAlign: "left",
  padding: "12px",
  fontSize: "15px",
};

const tdStyle = {
  padding: "12px",
  borderBottom: "1px solid #ddd",
  fontSize: "14px",
  color: colors.deepBlue,
};

const actionButton = {
  padding: "6px 12px",
  borderRadius: "6px",
  border: "none",
  cursor: "pointer",
  fontSize: "14px",
  marginRight: "6px",
};

function ManageCustomers() {
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    // Example API call - replace with your backend endpoint
    axios
      .get("https://your-api/customers")
      .then((res) => setCustomers(res.data))
      .catch((err) => {
        console.error(err);
        // fallback mock data for now
        setCustomers([
          {
            id: 1,
            name: "John Doe",
            email: "john.doe@email.com",
            account: "US123456789",
            country: "USA",
          },
          {
            id: 2,
            name: "Sarah Smith",
            email: "sarah.smith@email.com",
            account: "GB987654321",
            country: "UK",
          },
          {
            id: 3,
            name: "Michael Brown",
            email: "michael.brown@email.com",
            account: "DE456789123",
            country: "Germany",
          },
        ]);
      });
  }, []);

  return (
    <div style={containerStyle}>
      <div style={cardStyle}>
        <h2 style={headingStyle}> Manage Customers</h2>
        <table style={tableStyle}>
          <thead>
            <tr>
              <th style={thStyle}>Name</th>
              <th style={thStyle}>Email</th>
              <th style={thStyle}>Account</th>
              <th style={thStyle}>Country</th>
              <th style={thStyle}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {customers.map((c) => (
              <tr key={c.id}>
                <td style={tdStyle}>{c.name}</td>
                <td style={tdStyle}>{c.email}</td>
                <td style={tdStyle}>{c.account}</td>
                <td style={tdStyle}>{c.country}</td>
                <td style={tdStyle}>
                  <button
                    style={{ ...actionButton, backgroundColor: colors.yellowOrange, color: colors.deepBlue }}
                    onClick={() => alert(`Viewing ${c.name}`)}
                  >
                    View
                  </button>
                  <button
                    style={{ ...actionButton, backgroundColor: colors.orangeRed, color: "#fff" }}
                    onClick={() => alert(`Editing ${c.name}`)}
                  >
                    Edit
                  </button>
                  <button
                    style={{ ...actionButton, backgroundColor: "#ef4444", color: "#fff" }}
                    onClick={() => alert(`Deleting ${c.name}`)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ManageCustomers;
