import React, { useEffect, useState } from "react";
import axios from "axios";

// Theme colors
const colors = {
  deepBlue: "#0D1B2A",
  orangeRed: "#FF4500",
  yellowOrange: "#FFA500",
  white: "#ffffff",
};

const containerStyle = {
  minHeight: "100vh",
  backgroundColor: colors.deepBlue,
  padding: "40px",
  fontFamily: "'Segoe UI', sans-serif",
  color: colors.white,
};

const cardStyle = {
  backgroundColor: colors.white,
  borderRadius: "12px",
  padding: "24px",
  boxShadow: "0 4px 15px rgba(0,0,0,0.15)",
};

const headingStyle = {
  fontSize: "22px",
  fontWeight: "600",
  marginBottom: "20px",
  color: colors.deepBlue,
};

const tableStyle = {
  width: "100%",
  borderCollapse: "collapse",
};

const thStyle = {
  backgroundColor: colors.orangeRed,
  color: colors.white,
  textAlign: "left",
  padding: "12px",
  fontSize: "15px",
};

const tdStyle = {
  padding: "12px",
  borderBottom: "1px solid #ddd",
  fontSize: "14px",
  color: colors.deepBlue,
};

const statusBadge = (status) => ({
  padding: "6px 12px",
  borderRadius: "20px",
  fontWeight: "500",
  backgroundColor:
    status === "Completed"
      ? colors.yellowOrange
      : status === "Pending"
      ? "#facc15"
      : "#ef4444",
  color: colors.deepBlue,
});

function EmployeePayments() {
  const [payments, setPayments] = useState([]);

  useEffect(() => {
    // Example API call - replace with your backend endpoint
    axios
      .get("https://your-api/payments")
      .then((res) => setPayments(res.data))
      .catch((err) => {
        console.error(err);
        // fallback mock data for now
        setPayments([
          {
            id: 1,
            customer: "John Doe",
            account: "US123456789",
            amount: 500,
            currency: "USD",
            swiftCode: "BOFAUS3N",
            status: "Completed",
          },
          {
            id: 2,
            customer: "Sarah Smith",
            account: "GB987654321",
            amount: 1200,
            currency: "GBP",
            swiftCode: "BARCGB22",
            status: "Pending",
          },
          {
            id: 3,
            customer: "Michael Brown",
            account: "DE456789123",
            amount: 800,
            currency: "EUR",
            swiftCode: "DEUTDEFF",
            status: "Failed",
          },
        ]);
      });
  }, []);

  return (
    <div style={containerStyle}>
      <div style={cardStyle}>
        <h2 style={headingStyle}> View All Payments</h2>
        <table style={tableStyle}>
          <thead>
            <tr>
              <th style={thStyle}>Customer</th>
              <th style={thStyle}>Account</th>
              <th style={thStyle}>Amount</th>
              <th style={thStyle}>Currency</th>
              <th style={thStyle}>SWIFT Code</th>
              <th style={thStyle}>Status</th>
            </tr>
          </thead>
          <tbody>
            {payments.map((p) => (
              <tr key={p.id}>
                <td style={tdStyle}>{p.customer}</td>
                <td style={tdStyle}>{p.account}</td>
                <td style={tdStyle}>${p.amount.toLocaleString()}</td>
                <td style={tdStyle}>{p.currency}</td>
                <td style={tdStyle}>{p.swiftCode}</td>
                <td style={tdStyle}>
                  <span style={statusBadge(p.status)}>{p.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default EmployeePayments;
